import * as cheerio from 'cheerio';
export default async function handler(request) {
 if(request.method !== 'GET') return new Response('Method not allowed',{status:405});
 try {
  const r=await fetch('https://anicine.sbs/',{signal:AbortSignal.timeout(12000),headers:{'User-Agent':'Mozilla/5.0 (compatible; NexusCatalog/1.0)'}});
  if(!r.ok) throw Error('AniCine returned HTTP '+r.status);
  const html=await r.text(); if(html.length>5000000) throw Error('Response too large');
  const $=cheerio.load(html), seen=new Set(),items=[];
  $('a[href^="/watch/"]').each((_,a)=>{
   const href=$(a).attr('href')||'';const m=href.match(/^\/watch\/(movie|tv|anime)\/(\d+)-[a-z0-9-]+$/i);if(!m||seen.has(href))return;
   const img=$(a).find('img').first();const title=(img.attr('alt')||'').trim();const poster=img.attr('src')||'';
   if(!title||title.length>200||!(/^(?:https:\/\/image\.tmdb\.org\/t\/p\/[a-z0-9]+\/[a-zA-Z0-9._-]+|https:\/\/s4\.anilist\.co\/file\/anilistcdn\/media\/anime\/cover\/[a-z]+\/[a-zA-Z0-9._-]+)$/.test(poster)))return;
   const year=($(a).text().match(/(?:19|20)\d{2}/)||[])[0]||'';
   seen.add(href);items.push({title,year,kind:m[1],id:m[2],poster,url:'https://anicine.sbs'+href});
  });
  return Response.json({source:'AniCine homepage',fetchedAt:new Date().toISOString(),items:items.slice(0,200),note:'Homepage listings only; playback, rights and availability are not verified.'},{headers:{'Cache-Control':'public, max-age=300'}});
 } catch(e){return Response.json({error:'AniCine listings unavailable',items:[]},{status:502,headers:{'Cache-Control':'no-store'}})}
}
