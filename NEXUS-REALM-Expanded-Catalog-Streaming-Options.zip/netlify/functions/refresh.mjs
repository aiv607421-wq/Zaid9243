import {getStore} from '@netlify/blobs';
// Catalog snapshots only. This function does not acquire or host videos.
export async function collect(){
  const jobs=['movies','tv'].map(async kind=>{const u=new URL('https://vidspark.to/api/discover/'+kind);u.searchParams.set('page','1');u.searchParams.set('resultsPerPage','40');u.searchParams.set('ordering','last_upload_date');u.searchParams.set('direction','desc');const r=await fetch(u,{signal:AbortSignal.timeout(12000)});if(!r.ok)throw Error(kind+' feed failed');const j=await r.json();if(!Array.isArray(j.data))throw Error('Unexpected provider response');return j.data.filter(x=>/^\d+$/.test(String(x.tmdbid||''))).map(x=>({id:'live-'+kind+'-'+x.tmdbid,t:String(x.orig_title||'Untitled'),y:x.year||'—',k:kind==='tv'?'series':'movie',ind:'live',c:'',l:'en',q:'',imdb:/^tt\d+$/.test(x.imdb_id||'')?x.imdb_id:null,sourceTime:x.last_update||'',g:[]}))});
  jobs.push((async()=>{const q='query { Page(page:1,perPage:30) { media(type:ANIME,sort:TRENDING_DESC) { id title { english romaji } coverImage { large } startDate { year } } } }';const r=await fetch('https://graphql.anilist.co',{method:'POST',headers:{'Content-Type':'application/json',Accept:'application/json'},body:JSON.stringify({query:q}),signal:AbortSignal.timeout(12000)});if(!r.ok)throw Error('Anime feed failed');const j=await r.json();if(!Array.isArray(j.data?.Page?.media))throw Error('Unexpected anime response');return j.data.Page.media.map(x=>({id:'anilist-'+x.id,t:x.title.english||x.title.romaji||'Untitled',y:x.startDate?.year||'—',k:'anime',ind:'live',c:'',l:'ja',q:'',poster:x.coverImage?.large||'',g:[]}))})());
  const results=await Promise.allSettled(jobs),ok=results.filter(r=>r.status==='fulfilled');if(!ok.length)throw Error('All upstream feeds failed');return {items:ok.flatMap(r=>r.value).slice(0,110),at:Date.now(),partial:ok.length<jobs.length,sources:{movies:results[0].status==='fulfilled',tv:results[1].status==='fulfilled',anime:results[2].status==='fulfilled'}};
}
// Compare only successful movie-feed snapshots; keep the last successful state
// through partial upstream failures, and do not mislabel the first baseline as new.
export function mergeMovieHistory(snapshot, previous) {
  const old=previous||{};
  const legacy=(Array.isArray(old.items)?old.items:[]).filter(t=>t.k==='movie'&&String(t.id||'').startsWith('live-movies-'));
  const prior=old.movieState && Array.isArray(old.movieState.items) ? old.movieState : (legacy.length ? {items:legacy,at:old.at||0} : null);
  let history=Array.isArray(old.movieHistory)?old.movieHistory.slice(0,23):[];
  let state=prior;
  const latest=(Array.isArray(snapshot.items)?snapshot.items:[]).filter(t=>t.k==='movie'&&String(t.id||'').startsWith('live-movies-'));
  if(snapshot.sources?.movies && latest.length){
    const seen=new Set((prior?.items||[]).map(t=>String(t.id)));
    const added=prior?latest.filter(t=>!seen.has(String(t.id))):[];
    history=[{at:snapshot.at,kind:prior?'comparison':'baseline',added,checked:latest.length},...history].slice(0,24);
    state={at:snapshot.at,items:latest};
  }
  return {...snapshot,movieState:state,movieHistory:history,movieHistoryVersion:1};
}
export default async function refresh(){try{const snapshot=await collect();const store=getStore('nexus-catalog');let previous;try{previous=await store.get('latest',{type:'json'})}catch(e){console.error('Previous snapshot unavailable; aborting to avoid losing history:',e.message);return}const updated=mergeMovieHistory(snapshot,previous);await store.setJSON('latest',updated);console.log(`Updated ${updated.items.length} listings; movie history ${updated.movieHistory.length} runs`)}catch(e){console.error('Refresh failed; previous snapshot preserved:',e.message)}}
export const config={schedule:'@hourly'};
